﻿namespace PetClinic.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-OAP1RAB\SQLEXPRESS;Database=PetClinicExam;Trusted_Connection=True";
    }
}
